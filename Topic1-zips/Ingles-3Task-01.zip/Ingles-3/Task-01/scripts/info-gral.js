




//Código cuando hace scroll van apareciendo las secciones

ScrollReveal().reveal('.card-inicio');
ScrollReveal().reveal('.presentacion', { delay: 500 });
ScrollReveal().reveal('.acreditacion', { delay: 500 });
ScrollReveal().reveal('.dinamica', { delay: 500 });
ScrollReveal().reveal('.lineamientos', { delay: 500 });

//----------------------------------------------------------------
